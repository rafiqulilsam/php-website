<?php
include 'header.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>FoodLover</title>
	<link rel="sortcut icon" type="image/png" href="image/icon.png">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/about.css">
</head>
<body>
	
<!-- silder add koris aikhane -->
	<div class="container">
		<div class="row d-flex flex-row">
		<div class="col-md-6 d-flex align-items-center"><img class="image2" src="image/th.jpg" alt=""><img class="image" src="image/th2.jpg" alt=""></div>
		<div class="col-md-6">
			<h1 class="table">About Our resturant</h1>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
			 took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
		</div>
	</div>

	<div class="table">
		<h3>Available Restaurent</h3>
		<table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Restaurent</th>
      <th scope="col">Open Time</th>
      <th scope="col">Close Time</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Red Chili</td>
      <td>10:30 AM</td>
      <td>11:30 PM</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>7DAYZ</td>
      <td>10:00 AM</td>
      <td>11:00 PM</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Handi</td>
      <td>11:00 AM </td>
      <td>12:00 AM</td>
    </tr>
    <tr>
      <th scope="row">1</th>
      <td>Red Chili</td>
      <td>10:30 AM</td>
      <td>11:30 PM</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>7DAYZ</td>
      <td>10:00 AM</td>
      <td>11:00 PM</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Handi</td>
      <td>11:00 AM </td>
      <td>12:00 AM</td>
    </tr>
    
  </tbody>
	</table>
	</div>
	</div>



	
<?php include 'footer.php'; ?>
</body>
</html>