<!DOCTYPE html>
<html>
<head>
	<title>FoodLover</title>
	<link rel="sortcut icon" type="image/png" href="image/icon.png">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/footer.css">
	<style type="">
		.text a{
			color: #c0392b;
			padding-left: 20px;
		}
	</style>
</head>
<body>
	<footer style="background-image: url(image/cover.jpg); background-repeat: no-repeat; background-size: cover;">
		<div class="text">
			<a href="about.php">About Us</a>
			<a href="">Contact Us</a>
		</div>
		<div class="icon">
			<h2 style="font-family: somthing; color: blue; margin-left: 20%; margin-top: 10px;">Follow Us</h2>
			<ul>
				<a style="margin-left: 50px;" href=""><li><i class="fa fa-facebook"></i></li></a>
				<a href=""><li><i class="fa fa-twitter"></i></li></a>
				<a href=""><li><i class="fa fa-linkedin"></i></li></a>
			</ul>
		</div>
	</footer>
</body>
</html>